# PHP & MongoDB Tutorials
Basic php tutorials on mongodb

## Test with docker
```
docker build -t {container_name} .
docker run -it {container_name} bash
```
